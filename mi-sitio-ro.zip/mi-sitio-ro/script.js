window.onload = function() {
  alert("¡Bienvenid@ al mundo de los videojuegos!");
}